 
INSERT IGNORE INTO `role` (`role_id`,`role`)
VALUES(1,'USER'),(2,'DBA'),(3,'ADMIN');